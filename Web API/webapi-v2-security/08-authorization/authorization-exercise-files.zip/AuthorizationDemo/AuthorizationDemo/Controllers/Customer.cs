﻿
namespace AuthorizationDemo.Controllers
{
    public class Customer
    {
        public string Region { get; set; }
    }
}
