The CORS demo can be found here:
https://github.com/thinktecture/Thinktecture.AuthorizationServer/tree/master/samples/Flows