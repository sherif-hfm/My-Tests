﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace MomraWebApplicationWcf
{
    [DataContract]
    public class LicenseResponse
    {
        /// <summary>
        /// بيانات الخطأ إن وجد
        /// </summary>
        [DataMember]
        public string ErrorMessage { get; set; }

        /// <summary>
        /// رقم فاتورة سداد
        /// </summary>
        [DataMember]
        public long SadadBillNumber { get; set; }


        /*Edit: Added fields*/

        /// <summary>
        /// تاريخ انتهاء فاتورة سداد
        /// </summary>
        [DataMember]
        public DateTime? SadadExpiryDate { get; set; }

        /// <summary>
        /// رقم المفوتر الخاص بـ سداد
        /// </summary>
        [DataMember]
        public string SadadBillerId { get; set; }

        /* End of Added fields*/


        /// <summary>
        /// رقم الحالة
        /// 1 - Success
        /// 0 - Failure
        /// </summary>
        [DataMember]
        public int StatusCode { get; set; }

        /// <summary>
        /// نص وصف الحالة
        /// </summary>
        [DataMember]
        public string StatusName { get; set; }
    }

    [DataContract]
    public class SadadResponse
    {
        /// <summary>
        /// بيانات الخطأ إن وجد
        /// </summary>
        [DataMember]
        public string ErrorMessage { get; set; }

        /// <summary>
        /// نتيجة الدفع
        /// </summary>
        [DataMember]
        public bool PaymentResult { get; set; }

        /// <summary>
        /// تاريخ الدفع ان وجد
        /// </summary>
        [DataMember]
        public DateTime? PaymentDate { get; set; }
    }

    /// <summary>
    /// بيانات الرخصة
    /// </summary>
    [DataContract]
    public class LicenseDetails
    {
        /// <summary>
        /// نوع مقدم الطلب
        /// 1 - مالك المحل نفسه
        /// 2 - وكيل عن مالك المحل
        /// 3 - مفوض من قبل مالك المحل
        /// </summary>
        [DataMember]
        [Required]
        [Range(minimum: 1, maximum: 3)]
        public int SubmitterTypeId { get; set; }

        /// <summary>
        /// بيانات المالك
        /// </summary>
        [DataMember]
        public LicenseOwnerInfo OwnerInfo { get; set; }

        /// <summary>
        /// بيانات المفوض أو الوكيل
        /// </summary>
        [DataMember]
        public LicenseAgentInfo AgentInfo { get; set; }

        /// <summary>
        /// المرفقات
        /// </summary>
        [DataMember]
        public LicenseAttachmentInfo[] AttachmentsInfo { get; set; }

        /// <summary>
        /// قائمة بيانات الأنشطة
        /// </summary>
        [DataMember]
        public LicenseActivityInfo[] ActivitiesInfo { get; set; }

        /// <summary>
        /// قائمة بيانات اللوحات
        /// </summary>
        [DataMember]
        public LicenseBoardInfo[] BoardsInfo { get; set; }

        /// <summary>
        /// قائمة بيانات التكاليف
        /// </summary>
        [DataMember]
        public LicenseCostInfo[] CostsInfo { get; set; }

        /// <summary>
        /// نوع توصيل الرخصة
        /// 1 - توصيل عن طريق واصل
        /// 2 - استلام عن طريق البلدية
        /// 3 - عن طريق البريد الالكتروني
        /// </summary>
        [DataMember]
        public int LicenseDeliveryType { get; set; }

        /// <summary>
        /// رقم الرخصة
        /// </summary>
        [DataMember]
        public long MomraLicenseId { get; set; }

        /// <summary>
        /// بيانات عنوان المحل
        /// </summary>
        [DataMember]
        public LicenseShopAddressInfo ShopAddressInfo { get; set; }

        /// <summary>
        /// بيانات المحل
        /// </summary>
        [DataMember]
        public LicenseShopInfo ShopInfo { get; set; }

        /// <summary>
        /// إجمالي التكلفة
        /// </summary>
        [DataMember]
        public decimal TotalCost { get; set; }

        /// <summary>
        /// بيانات واصل
        /// </summary>
        [DataMember]
        public LicenseWaselAddressInfo WaselAddressInfo { get; set; }

        /// <summary>
        /// بيانات إضافية
        /// </summary>
        [DataMember]
        public Dictionary<string, string> DynamicFields { get; set; }

    }

    [DataContract]
    public class LicenseOwnerInfo
    {
        /// <summary>
        /// الاسم الأول
        /// </summary>
        [DataMember]
        //[Required]
        public string FirstName { get; set; }

        /// <summary>
        /// الاسم الثاني
        /// </summary>
        [DataMember]
        //[Required]
        public string SecondName { get; set; }

        /// <summary>
        /// الاسم الثالث
        /// </summary>
        [DataMember]
        //[Required]
        public string ThirdName { get; set; }

        /// <summary>
        /// الاسم الأخير
        /// </summary>
        [DataMember]
        //[Required]
        public string FourthName { get; set; }

        /// <summary>
        /// تاريخ الميلاد
        /// </summary>
        [DataMember]
        public string BirthDate { get; set; }

        /// <summary>
        /// اسم الشركة
        /// </summary>
        [DataMember]
        public string CompanyName { get; set; }

        /// <summary>
        /// نوع الهوية
        /// 1  هوية وطنية
        /// 2 اقامة
        /// 3 شركة أو مؤسسة
        /// </summary>
        [DataMember]
        [Required]
        [Range(minimum: 1, maximum: 3)]
        public int IdentityType { get; set; }

        /// <summary>
        /// رقم الهوية أو السجل التجاري
        /// </summary>
        [DataMember]
        [Required]
        [MaxLength(length: 10)]
        [MinLength(length: 10)]
        public string IdentityNumber { get; set; }

        /// <summary>
        /// مصدر الهوية
        /// </summary>
        [DataMember]
        public string IdentitySource { get; set; }

        /// <summary>
        /// تاريخ اصدار الهوية
        /// </summary>
        [DataMember]
        public DateTime IdentityIssueDate { get; set; }

        /// <summary>
        /// تاريخ انتهاء الهوية
        /// </summary>
        [DataMember]
        public DateTime IdentityExpiryDate { get; set; }

        /// <summary>
        /// الجوال
        /// </summary>
        [DataMember]
        [Required]
        public string Mobile { get; set; }

        /// <summary>
        /// البريد الالكتروني
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// الجنس
        /// </summary>
        [DataMember]
        public int Gender { get; set; }
    }

    /// <summary>
    /// بيانات مقدم الطلب في حالة مفوض أو وكيل
    /// بيانات الوكيل أو المفوض
    /// </summary>
    [DataContract]
    public class LicenseAgentInfo
    {
        /// <summary>
        /// تاريخ الوكالة / التفويض
        /// </summary>
        [DataMember]
        public string AuthorizationDate { get; set; }

        /// <summary>
        /// رقم الوكالة/التفويض
        /// </summary>
        [DataMember]
        public string AuthorizationNumber { get; set; }

        /// <summary>
        /// تاريخ الميلاد
        /// </summary>
        [DataMember]
        public string BirthDate { get; set; }

        /// <summary>
        /// الاسم الأول
        /// </summary>
        [DataMember]
        public string FirstName { get; set; }

        /// <summary>
        /// الاسم الثاني
        /// </summary>
        [DataMember]
        public string SecondName { get; set; }

        /// <summary>
        /// الاسم الثالث
        /// </summary>
        [DataMember]
        public string ThirdName { get; set; }

        /// <summary>
        /// الاسم الأخير
        /// </summary>
        [DataMember]
        public string FourthName { get; set; }

        /// <summary>
        /// نوع الهوية
        /// 1  هوية وطنية
        /// 2 اقامة
        /// </summary>
        [DataMember]
        [Range(minimum: 1, maximum: 2)]
        public int IdentityType { get; set; }

        /// <summary>
        /// رقم الهوية
        /// </summary>
        [DataMember]
        public string IdentityNumber { get; set; }

        /// <summary>
        /// مصدر الهوية
        /// </summary>
        [DataMember]
        public string IdentitySource { get; set; }

        /// <summary>
        /// تاريخ اصدار الهوية
        /// </summary>
        [DataMember]
        public DateTime IdentityIssueDate { get; set; }

        /// <summary>
        /// تاريخ انتهاء الهوية
        /// </summary>
        [DataMember]
        public DateTime IdentityExpiryDate { get; set; }

        /// <summary>
        /// الجوال
        /// </summary>
        [DataMember]
        public string Mobile { get; set; }

        /// <summary>
        /// البريد الالكتروني
        /// </summary>
        [DataMember]
        public string Email { get; set; }

        /// <summary>
        /// الجنس
        /// </summary>
        [DataMember]
        public int Gender { get; set; }
    }

    [DataContract]
    public class LicenseAttachmentInfo
    {
        /// <summary>
        /// نوع المرفق
        ///1285	رسم توضيحي (كروكي) لموقع وعنوان المحل وإحداثياته
        ///1286	رخصة البناء
        ///1287	شهادة إتمام البناء
        ///1288	عقد الايجار 
        ///1290	صورة الوكالة الشرعية وبطاقة الوكيل مع الأصل للمطابقة إذا كانت صاحبة الطلب إمرأة
        ///1291	صورة خارجية لواجهة المحل
        /// </summary>
        [DataMember]
        [Required]
        [Range(minimum: 1200, maximum: 1300)]
        public string AtachmentTypeId { get; set; }

        /// <summary>
        /// رابط تنزيل المرفق
        /// </summary>
        [DataMember]
        [Required]
        public string AtachmentURL { get; set; }
    }

    [DataContract]
    public class LicenseActivityInfo
    {
        /// <summary>
        /// فئة الفندق
        /// يستخدم في حالة الفندق والشقق المفروشة والوحدات السكنية
        /// 1- Category 1
        /// 2- Category 2
        /// 3- Category 3
        /// 4- Category 4
        /// 5- Category 5
        /// </summary>
        [DataMember]
        [Required]
        [Range(minimum: 1, maximum: 9)]
        public int AccommodationTypeId { get; set; }

        /// <summary>
        /// رقم المدينة
        /// </summary>
        [DataMember]
        public int CityId { get; set; }

        /// <summary>
        /// كود تكلفة النشاط
        /// </summary>
        [DataMember]
        public int IsicCostCode { get; set; }

        /// <summary>
        /// رقم النشاط
        /// </summary>
        [DataMember]
        public int IsicId { get; set; }

        /// <summary>
        /// رقم النشاط الفرعي
        /// </summary>
        [DataMember]
        public int IsicSubId { get; set; }

        /// <summary>
        /// فئة المدينة
        /// </summary>
        [DataMember]
        public int SegmentId { get; set; }

        /// <summary>
        /// قيمة التكلفة
        /// </summary>
        [DataMember]
        public int CostValue { get; set; }
    }

    [DataContract]
    public class LicenseShopAddressInfo
    {
        /// <summary>
        /// رقم المبنى
        /// </summary>
        [DataMember]
        public string BuildingNumber { get; set; }

        /// <summary>
        /// كود الحي
        /// </summary>
        [DataMember]
        public int DistrictCode { get; set; }

        /// <summary>
        /// اسم الحي
        /// </summary>
        [DataMember]
        public string DistrictName { get; set; }

        /// <summary>
        /// كود الحي الفرعي
        /// </summary>
        [DataMember]
        public int SubDistrictCode { get; set; }

        /// <summary>
        ///  اسم الحي الفرعي
        /// </summary>
        [DataMember]
        public string SubDistrictName { get; set; }

        /// <summary>
        /// رقم طابق المحل
        /// </summary>
        [DataMember]
        [Required]
        public string FloorNumber { get; set; }

        /// <summary>
        /// رقم قطعة الأرض
        /// </summary>
        [DataMember]
        [Required]
        public string LandNumber { get; set; }

        /// <summary>
        /// خط العرض
        /// </summary>
        [DataMember]
        [Required]
        public string Latitude { get; set; }

        /// <summary>
        /// خط الطول
        /// </summary>
        [DataMember]
        [Required]
        public string Longitude { get; set; }

        /// <summary>
        /// وصف الموقع
        /// </summary>
        [DataMember]
        public string LocationDescription { get; set; }

        /// <summary>
        /// رقم المول
        /// </summary>
        [DataMember]
        public int MallCode { get; set; }

        /// <summary>
        /// اسم المول
        /// </summary>
        [DataMember]
        public string MallName { get; set; }

        /// <summary>
        /// رقم المخطط
        /// </summary>
        [DataMember]
        [Required]
        public string PlanNumber { get; set; }

        /// <summary>
        /// رقم المحل في المبنى
        /// </summary>
        [DataMember]
        public string ShopUnitNumber { get; set; }

        /// <summary>
        /// كود الشارع
        /// </summary>
        [DataMember]
        public int StreetCode { get; set; }

        /// <summary>
        /// اسم الشارع
        /// </summary>
        [DataMember]
        public string StreetName { get; set; }

        /// <summary>
        /// كود الأمانة
        /// </summary>
        [DataMember]
        public string MunicipalityCode { get; set; }

        /// <summary>
        /// اسم الأمانة
        /// </summary>
        [DataMember]
        public string MunicipalityName { get; set; }

        /// <summary>
        /// كود البلدية
        /// </summary>
        [DataMember]
        [MaxLength(length: 2)]
        public string SubMunicipalityCode { get; set; }

        /// <summary>
        /// اسم البلدية
        /// </summary>
        [DataMember]
        public string SubMunicipalityName { get; set; }
    }

    [DataContract]
    public class LicenseCostInfo
    {
        /// <summary>
        /// وصف تكلفة الوحدة
        /// </summary>
        [DataMember]
        public string CostItemDescription { get; set; }

        /// <summary>
        /// نوع التكلفة
        /// 44 - نشاط
        /// 28 - ارشادية
        /// 29 - اعلانية
        /// 36 - تكلفة الزيارة
        /// </summary>
        [DataMember]
        [Required]
        [MaxLength(length: 2)]
        public int CostItemTypeId { get; set; }

        /// <summary>
        /// قيمة التكلفة
        /// </summary>
        [DataMember]
        [Required]
        public decimal CostItemValue { get; set; }
    }

    [DataContract]
    public class LicenseBoardInfo
    {
        /// <summary>
        /// نوع اللوحة
        /// -1 : لا يوجد لوحات
        /// 1 : لوحة إرشادية
        /// 2 : لوحة إعلانية
        /// 3 : لوحة أرشادية و إعلانية
        /// </summary>
        [DataMember]
        [Required]
        public int BoardTypeId { get; set; }

        /// <summary>
        /// طول اللوحة
        /// </summary>
        [DataMember]
        public int BoardLength { get; set; }

        /// <summary>
        /// عرض اللوحة
        /// </summary>
        [DataMember]
        public int BoardWidth { get; set; }
    }

    [DataContract]
    public class LicenseWaselAddressInfo
    {

        /// <summary>
        /// رقم المبنى
        /// </summary>
        [DataMember]
        [Required]
        public string BuildingNumber { get; set; }

        /// <summary>
        /// رقم الوحدة
        /// </summary>
        [DataMember]
        [Required]
        public string UnitNumber { get; set; }

        /// <summary>
        /// رقم البريد
        /// </summary>
        [DataMember]
        public string ZipCode { get; set; }

        /// <summary>
        /// الرقم الإضافي
        /// </summary>
        [DataMember]
        [Required]
        public string AdditionalNumber { get; set; }

        /// <summary>
        /// اسم الحي بالعربية
        /// </summary>
        [DataMember]
        public string DistrictNameAr { get; set; }

        /// <summary>
        /// اسم الحي بالانجليزية
        /// </summary>
        [DataMember]
        public string DistrictNameEn { get; set; }

        /// <summary>
        /// رقم المستلم
        /// </summary>
        [DataMember]
        public string RecipientId { get; set; }

        /// <summary>
        /// جوال المستلم
        /// </summary>
        [DataMember]
        public string RecipientMobile { get; set; }

        /// <summary>
        /// رقم المرجع
        /// </summary>
        [DataMember]
        public string ReferenceNumber { get; set; }

        /// <summary>
        /// اسم الشارع بالعربية
        /// </summary>
        [DataMember]
        public string StreetNameAr { get; set; }

        /// <summary>
        /// اسم الشارع بالإنجليزية
        /// </summary>
        [DataMember]
        public string StreetNameEn { get; set; }
    }

    [DataContract]
    public class LicenseShopInfo
    {
        /// <summary>
        /// تاريخ رخصة البناء
        /// </summary>
        [DataMember]
        [Required]
        public string BuildingLicenseDate { get; set; }

        /// <summary>
        /// رقم رخصة البناء
        /// </summary>
        [DataMember]
        [Required]
        public int BuildingLicenseNumber { get; set; }

        /// <summary>
        /// اسم مالك البناء
        /// </summary>
        [DataMember]
        [Required]
        public string BuildingOwnerName { get; set; }

        /// <summary>
        /// نوع الزبائن
        /// 1 رجال
        /// 2 نساء
        /// 3 رجال ونساء
        /// </summary>
        [DataMember]
        public int ClientsType { get; set; }

        /// <summary>
        /// نوع العمالة
        /// 1 رجال
        /// 2 نساء
        /// 3 رجال ونساء
        /// </summary>
        [DataMember]
        [Required]
        public int WorkersType { get; set; }

        /// <summary>
        /// رقم السجل التجاري
        /// </summary>
        [DataMember]
        public long CrNumber { get; set; }

        /// <summary>
        /// عدد الفتحات/الأبواب
        /// </summary>
        [DataMember]
        public int DoorCount { get; set; }

        /// <summary>
        /// عدد الأدوار في المبنى
        /// </summary>
        [DataMember]
        //[Required]
        public int FloorCount { get; set; }

        /// <summary>
        /// مساحة المحل
        /// </summary>
        [DataMember]
        [Required]
        public decimal ShopArea { get; set; }

        /// <summary>
        /// طول المحل
        /// </summary>
        [DataMember]
        [Required]
        public decimal ShopLength { get; set; }

        /// <summary>
        /// عرض المحل
        /// </summary>
        [DataMember]
        [Required]
        public decimal ShopWidth { get; set; }

        /// <summary>
        /// اسم المحل
        /// </summary>
        [DataMember]
        [Required]
        public string ShopName { get; set; }
    }
}