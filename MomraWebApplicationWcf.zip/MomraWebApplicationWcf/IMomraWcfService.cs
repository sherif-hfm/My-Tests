﻿using System;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace MomraWebApplicationWcf
{
    [ServiceContract]
    public interface IServiceMomraInstantPermitLicense
    {
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "CreateLicense/", RequestFormat = WebMessageFormat.Json,
            ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        LicenseResponse CreateLicense(LicenseDetails licenseDetails);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "/CheckSadadBillStatus/{sadadBillNo}"
            , RequestFormat = WebMessageFormat.Json
            , ResponseFormat = WebMessageFormat.Json
            /*, BodyStyle = WebMessageBodyStyle.WrappedResponse*/
            )]
        SadadResponse CheckSadadBillStatus(string sadadBillNo);


        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "Test"
            , RequestFormat = WebMessageFormat.Json
            , ResponseFormat = WebMessageFormat.Json
            , BodyStyle = WebMessageBodyStyle.Bare
            /*, BodyStyle = WebMessageBodyStyle.WrappedResponse*/
            )]
        string Test();
    }
}
