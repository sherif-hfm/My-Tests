﻿using System.ServiceModel;
using System.ServiceModel.Activation;

namespace MomraWebApplicationWcf
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single/*,ReturnUnknownExceptionsAsFaults=true*/)]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class MomraInstantPermitLicenseService : IServiceMomraInstantPermitLicense
    {
        public SadadResponse CheckSadadBillStatus(string sadadBillNo)
        {
            SadadResponse response = new SadadResponse()
            {
                ErrorMessage = "Error message if exists",
                PaymentDate = null,
                PaymentResult = false
            };

            //TODO: Add your Bussiness code here

            return response;
        }

        public LicenseResponse CreateLicense(LicenseDetails licenseDetails)
        {
            LicenseResponse response = new LicenseResponse()
            {
                ErrorMessage = "Error message if exists",
                SadadBillNumber = -1,
                StatusCode = -1,
                StatusName = "Not yet implemented",
            };

            //TODO: Add your Bussiness code here

            return response;
        }

        public string Test()
        {
            return "Testing service succeeded";
        }
    }
}
